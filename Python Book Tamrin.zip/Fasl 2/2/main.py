#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jun 21 02:56:16 2023

@author: amir
"""

import numpy as np
import csv


from collections import defaultdict
data_path = './heart+disease/processed.cleveland.data'
n_users = 6040
n_movies = 3706

n_users = 610
n_movies = 9724
def load_rating_data(data_path):

    attributes=13
    N=303
    X=np.zeros((N,attributes))
    Y=np.zeros(N)
    
    with open(data_path, 'r') as file:

        csvreader = csv.reader(file)
        c=0
        for row in csvreader:
            for i in range(0,13):
                if(row[i]=='?'):
                    print('-')
                else:
                    print(float(row[i]))
                    X[c,i]=float(row[i])
            
            Y[c]=int(float(row[13]))
            c=c+1
            
            


        return X, Y



X, Y = load_rating_data(data_path)

def display_distribution(data):
    values, counts = np.unique(data, return_counts=True)
    for value, count in zip(values, counts):
        print(f'Number of rating {int(value)}: {count}')


print('Shape of X:', X.shape)
print('Shape of Y:', Y.shape)

display_distribution(Y)




n_0 = (Y == 0).sum()
n_1 = (Y == 1).sum()
n_2 = (Y == 2).sum()
n_3 = (Y == 3).sum()
n_4 = (Y == 4).sum()

print(n_0,n_1,n_2,n_3,n_4)


from sklearn.model_selection import train_test_split

X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.2, random_state=42)

print(len(Y_train), len(Y_test))

from sklearn.naive_bayes import MultinomialNB

clf = MultinomialNB(alpha=.50, fit_prior=True)


X_train=X_train+1
clf.fit(X_train, Y_train)

prediction_prob = clf.predict_proba(X_test)

print(prediction_prob[0:10])

prediction = clf.predict(X_test)

print(prediction)

accuracy = clf.score(X_train, Y_train)
print(f'The Train accuracy is: {accuracy*100:.1f}%')

accuracy = clf.score(X_test, Y_test)
print(f'The Test accuracy is: {accuracy*100:.1f}%')
